export const environment = {
    HOST: 'http://localhost:9090'
};
