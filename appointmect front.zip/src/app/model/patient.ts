export class Patient{
    idPatient: number;
    firstName: string;
    lastName: string;
    dni: string;
    phone: string;
    address: string;
    email: string;
}