export class Medic{
    idMedic: number;
    cmp: string;
    firstName: string;
    lastName: string; 
    photoUrl: string;
    idSpecialty: number;
}